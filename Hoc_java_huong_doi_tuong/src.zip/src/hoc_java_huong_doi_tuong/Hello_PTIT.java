/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoc_java_huong_doi_tuong;

/**
 *
 * @author Admin
 */
public class Hello_PTIT {
    public static void main(String[] args) {
        System.out.println("Hello PTIT.");
    }
}
